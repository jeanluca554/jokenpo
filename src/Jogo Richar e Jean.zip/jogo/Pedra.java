package jogo;
public class Pedra implements ObjetoEscolhido
{
    String resultado = "Pedra quebrou Tesoura";
    
    @Override
    public void Acao(String valor1, String valor2)
    {
        System.out.println(resultado);
        System.out.println("Os tipos foram " + valor1 + " x " + valor2);
    }
    
    @Override
    public void Empate()
    {
        System.out.println("Houve empate.\n");
        System.out.println("Os tipos foram Pedra x Pedra");
    }
}
