package jogo;
import java.util.ArrayList;
import java.util.Random;
public class Jogo 
{
    public static void main(String[] args) 
    {
        Pedra pedra = new Pedra();
        Papel papel = new Papel();
        Tesoura tesoura = new Tesoura();
        
        //O Random servirá para escolher valores para Pedra(0), Papel(1) e Tesoura(2)
        Random gerador = new Random();
         
        ArrayList confronto = new ArrayList(); //cria um Array para inserir os valores de acordo com o sorteio
        //int[] confronto = new int[2];
        for (int i = 0; i < 2; i++) 
        {
            switch (gerador.nextInt(3))
            {
                case 0:
                    confronto.add(pedra);
                    System.out.println("0");
                    break;

                case 1:
                    confronto.add(papel);
                    System.out.println("1");
                    break;

                case 2:
                    confronto.add(tesoura);
                    System.out.println("2");
            }
        }
        
        //Se o resultado for Pedra x Pedra
        if (confronto.get(0).equals(pedra) && confronto.get(1).equals(pedra))
        {
            pedra.Empate();
        }
        
        //Se o resultado for Pedra x Papel
        if (confronto.get(0).equals(pedra) && confronto.get(1).equals(papel))
        {
            papel.Acao("Pedra", "Papel");
        }
        
        //Se o resultado for Pedra x Tesoura
        if (confronto.get(0).equals(pedra) && confronto.get(1).equals(tesoura))
        {
            pedra.Acao("Pedra", "Tesoura");
        }
        
        //Se o resultado for Papel x Pedra
        if (confronto.get(0).equals(papel) && confronto.get(1).equals(pedra))
        {
            papel.Acao("Papel","Pedra");
        }
        
        //Se o resultado for Papel x Papel
        if (confronto.get(0).equals(papel) && confronto.get(1).equals(papel))
        {
            papel.Empate();
        }
        
        //Se o resultado for Papel x Tesoura
        if (confronto.get(0).equals(papel) && confronto.get(1).equals(tesoura))
        {
            tesoura.Acao("Papel","Tesoura");
        }
        
        //Se o resultado for Tesoura x Pedra
        if (confronto.get(0).equals(tesoura) && confronto.get(1).equals(pedra))
        {
            pedra.Acao("Tesoura","Pedra");
        }
        
        //Se o resultado for Tesoura x Papel
        if (confronto.get(0).equals(tesoura) && confronto.get(1).equals(papel))
        {
            tesoura.Acao("Tesoura","Papel");
        }
        
        //Se o resultado for Tesoura x Tesoura
        if (confronto.get(0).equals(tesoura) && confronto.get(1).equals(tesoura))
        {
            tesoura.Empate();
        }
    }
}
