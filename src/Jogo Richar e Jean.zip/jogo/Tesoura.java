package jogo;
public class Tesoura implements ObjetoEscolhido
{
    String cortar = "Tesoura cortou papel";
    
    @Override
    public void Acao(String valor1, String valor2)
    {
        System.out.println(cortar);
        System.out.println("Os tipos foram " + valor1 + " x " + valor2);
    }
    
    @Override
    public void Empate()
    {
        System.out.println("Houve empate.\n");
        System.out.println("Os tipos foram Tesoura x Tesoura");
    }
}