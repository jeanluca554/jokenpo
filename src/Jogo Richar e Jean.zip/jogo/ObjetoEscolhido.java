package jogo;
public interface ObjetoEscolhido 
{
    public void Acao(String valor1, String valor2);
    public void Empate();
}
